// Dashboard logic: polls /api/status once per second and renders it.
// Demo buttons POST to /api/demo/<action> (limp | outbreak | reset | calm | lively).

const $ = (id) => document.getElementById(id);

// Text helpers so values coming from the API are never injected as HTML
function el(tag, className, text) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  if (text !== undefined) e.textContent = text;
  return e;
}

const fmt = (v) => (v === null || v === undefined ? '--' : v);

function renderBanner(p1, demo) {
  let kind = p1.status.split(' ')[0];
  const prob = Math.round(p1.disease_prob * 100);
  let [title, detail] = {
    HEALTHY: ['All clear: PEN-01 healthy', `THI ${fmt(p1.thi)} • sick probability ${prob}%`],
    HEAT: ['Heat stress in PEN-01', `THI ${fmt(p1.thi)} is at or above 74: check ventilation and water`],
    QUARANTINE: ['Quarantine alert: PEN-01', `Sick probability ${prob}% • isolation gate PEN-04 locked`],
  }[kind] || [p1.status, ''];
  // A running demo shows its current step instead of the detail line
  if (demo) {
    if (demo.kind === 'outbreak' && demo.step === demo.steps) {
      title = 'Outbreak: 2 pens affected (PEN-01, PEN-03)';
      kind = 'QUARANTINE';
    }
    const name = demo.kind === 'outbreak' ? 'Outbreak demo' : 'Limping cow demo';
    detail = `${name}: step ${demo.step}/${demo.steps}, ${demo.text}`;
  }
  $('banner').className = 'banner ' + kind;
  $('banner-title').textContent = title;
  $('banner-detail').textContent = detail;
}

function renderPen1(p1, demo) {
  renderBanner(p1, demo);
  penAlert = p1.alert_active;
  const badge = $('p1-status');
  badge.textContent = p1.status;
  badge.className = 'badge ' + p1.status.split(' ')[0];
  $('pen1-card').className = p1.alert_active ? 'card pen1 alert' : 'card pen1';

  $('p1-label').textContent = p1.vision_label;
  $('p1-prob').textContent = Math.round(p1.disease_prob * 100) + '%';
  $('p1-thi').textContent = fmt(p1.thi);
  $('p1-temp').textContent = fmt(p1.temp_c);
  $('p1-hum').textContent = fmt(p1.humidity);
  $('p1-risk').textContent = p1.risk_score + '%';

  const sensor = $('p1-sensor');
  sensor.textContent = p1.sensor_online ? 'Sensor: Modulino Thermo online' : 'Sensor: offline';
  sensor.className = p1.sensor_online ? 'pill' : 'pill bad';
  $('p1-vision').textContent = p1.vision_active ? 'AI: gait model active' : 'AI: no gait model yet (demo)';

  $('p1-cows').textContent = p1.cows_detected
    ? `${p1.cows_detected} (${Math.round(p1.cow_conf * 100)}%)`
    : '0';
  $('p1-kpts').textContent = p1.pose_active && p1.cows_detected ? `${p1.keypoints_visible}/17` : '--';
  $('p1-detector').textContent = p1.detector_online ? 'Detector: YoloX nano' : 'Detector: starting...';
  $('p1-pose').textContent = p1.pose_active ? `Pose: RTMPose ${p1.pose_fps} fps` : 'Pose: off (no model)';
}

// Gait check: a cow starts a 2.5 s recording, then the pose + gait models analyse it;
// the verdict flashes over the camera if the cow is still there.
let gaitResultTime = null;

function renderGait(g) {
  const box = $('gait');
  if (!g) { box.hidden = true; return; }
  const r = g.result;
  if (r) {
    if (r.time !== gaitResultTime) {   // restart the flash for a new verdict
      gaitResultTime = r.time;
      box.className = '';
      void box.offsetWidth;
    }
    box.className = 'gait result ' + r.label;
    box.replaceChildren(el('b', '', r.label),
      el('span', '', `Lameness ${Math.round(r.prob * 100)}% • ${r.frames} frames`));
  } else if (g.phase === 'recording') {
    box.className = 'gait rec';
    box.replaceChildren(`Recording gait ${g.elapsed.toFixed(1)} / ${g.record_s} s`);
  } else if (g.phase === 'analysing') {
    box.className = 'gait';
    box.replaceChildren(`Analysing gait: frame ${g.done}/${g.total}`);
  } else if (g.note) {
    box.className = 'gait';
    box.replaceChildren(g.note);
  } else {
    box.hidden = true;
    return;
  }
  box.hidden = false;
}

// Camera: the detection brick streams frames ('image') and detections
// ('classification') over socket.io on port 4912. We draw them ourselves so the
// video matches the dashboard style. Boxes are in the frame's pixel coordinates.
const cameraImg = $('camera');
const cameraBoxes = $('camera-boxes');
const runnerUrl = `http://${location.hostname}:4912`;
let lastBoxes = [];
let penAlert = false;

function drawBoxes() {
  const w = cameraImg.clientWidth;
  const h = cameraImg.clientHeight;
  cameraBoxes.width = w;
  cameraBoxes.height = h;
  const ctx = cameraBoxes.getContext('2d');
  ctx.clearRect(0, 0, w, h);
  if (!cameraImg.naturalWidth) return;
  const sx = w / cameraImg.naturalWidth;
  const sy = h / cameraImg.naturalHeight;
  const color = penAlert ? '#ef4444' : '#22c55e';
  ctx.lineWidth = 3;
  ctx.font = '700 13px Manrope, system-ui, sans-serif';
  for (const b of lastBoxes) {
    const x = b.x * sx, y = b.y * sy;
    const text = `${b.label} ${Math.round((b.value || 0) * 100)}%`;
    ctx.strokeStyle = color;
    ctx.strokeRect(x, y, b.width * sx, b.height * sy);
    const tw = ctx.measureText(text).width + 10;
    ctx.fillStyle = color;
    ctx.fillRect(x - 1.5, Math.max(0, y - 20), tw, 20);
    ctx.fillStyle = '#04100a';
    ctx.fillText(text, x + 4, Math.max(14, y - 6));
  }
}

function showCamera(online) {
  cameraImg.parentElement.hidden = !online;
  $('camera-off').hidden = online;
}

function connectCamera() {
  const script = document.createElement('script');
  script.src = `${runnerUrl}/socket.io/socket.io.js`;
  script.onerror = () => { script.remove(); setTimeout(connectCamera, 3000); };   // brick still starting
  script.onload = () => {
    const socket = io.connect(runnerUrl, { transports: ['websocket'] });
    socket.on('connect', () => socket.emit('hello'));
    socket.on('disconnect', () => showCamera(false));
    socket.on('image', (msg) => {
      cameraImg.src = msg.img;
      showCamera(true);
    });
    socket.on('classification', (msg) => {
      lastBoxes = (msg.result && msg.result.bounding_boxes) || [];
      drawBoxes();
    });
  };
  document.head.appendChild(script);
}

cameraImg.addEventListener('load', drawBoxes);
window.addEventListener('resize', drawBoxes);
connectCamera();

const WEAK_RSSI = -70;   // dBm at or below this shows the signal in amber

function renderMesh(nodes, calm) {
  const cards = nodes.map((n) => {
    const card = el('div', 'card');
    const title = el('div');
    title.append(el('strong', '', n.id), ` (Zigbee: ${n.hops} hop${n.hops > 1 ? 's' : ''})`);
    title.className = 'card-head';
    const details = el('div', 'details');
    details.append(el('span', '', `${n.temp_c} °C`), el('span', '', `${n.humidity} %RH`),
      el('span', '', n.cows ? `Cows ${n.cows_in_view}/${n.cows} in view` : 'No cows'),
      el('span', '', `Sick ${Math.round(n.sick_prob * 100)}%`));
    card.append(title, el('span', 'badge ' + n.status.split(' ')[0], n.status),
      el('div', 'metric', `THI ${n.thi}`), details,
      el('div', n.rssi <= WEAK_RSSI ? 'signal weak' : 'signal',
        `Signal ${n.rssi} dBm • last packet ${n.last_rx_s}s ago`));
    return card;
  });
  $('mesh-cards').replaceChildren(...cards);

  $('mesh-mode-tag').textContent = calm ? 'simulated • calm' : 'simulated • lively';
  const btn = $('mesh-mode');
  btn.dataset.action = calm ? 'lively' : 'calm';
  btn.textContent = calm ? 'Make neighbour pens lively again' : 'Calm the neighbour pens';
}

async function refresh() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    renderPen1(data.pen1, data.demo);
    renderGait(data.gait);
    renderMesh(data.zigbee_mesh, data.mesh_calm);
    $('logs').textContent = data.zigbee_logs.join('\n') || 'Waiting for Zigbee mesh packets...';
    $('conn').textContent = '● Board connected';
    $('conn').className = 'conn ok';
  } catch (e) {
    $('conn').textContent = '● Board connection lost, retrying...';
    $('conn').className = 'conn bad';
  }
}

setInterval(() => { $('clock').textContent = new Date().toLocaleTimeString(); }, 1000);

document.querySelectorAll('button[data-action]').forEach((btn) => {
  btn.addEventListener('click', async () => {
    await fetch('/api/demo/' + btn.dataset.action, { method: 'POST' });
    refresh();
  });
});

setInterval(refresh, 1000);
refresh();
