// Artemis AI - MCU side (UNO Q)
//
// - Reads the Modulino Thermo every 2 s and sends it to Python (Bridge.notify "on_thermo_data")
// - Python decides if there is an anomaly and calls "set_alert_state" (true/false)
// - Alarm = flashing "!" on the LED matrix + beeping Modulino Buzzer, all non-blocking
// - Safety net: if Python stops talking for ALERT_TIMEOUT_MS, the alarm is silenced

#include <Arduino_RouterBridge.h>
#include <Arduino_LED_Matrix.h>
#include <Arduino_Modulino.h>

Arduino_LED_Matrix matrix;
ModulinoThermo thermo;
ModulinoBuzzer buzzer;

const unsigned long SENSOR_PERIOD_MS = 2000;   // Thermo sample period
const unsigned long BLINK_PERIOD_MS  = 350;    // Alarm blink / beep half-period
const unsigned long ALERT_TIMEOUT_MS = 15000;  // Python sends a heartbeat every 2 s
const int BEEP_FREQ_HZ = 880;
const int BEEP_LEN_MS  = 200;

bool thermoOk = false;
bool buzzerOk = false;

bool alertActive = false;
bool alertRequested = false;            // Last value received from Python
unsigned long lastAlertMsg = 0;         // millis() of the last set_alert_state
unsigned long lastSensorRead = 0;
unsigned long lastBlinkToggle = 0;
bool blinkOn = false;

// 8x13 frames, one byte per pixel, brightness 0-7 (row by row)
uint8_t iconHealthy[104] = {   // check mark
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,7,0,0,
  0,0,0,0,0,0,0,0,0,7,0,0,0,
  0,0,0,0,0,0,0,0,7,0,0,0,0,
  0,0,7,0,0,0,0,7,0,0,0,0,0,
  0,0,0,7,0,0,7,0,0,0,0,0,0,
  0,0,0,0,7,7,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t iconAlert[104] = {     // exclamation mark
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0,
  0,0,0,0,0,7,7,7,0,0,0,0,0
};

uint8_t iconSensorError[104] = { // "X" shown when the Thermo is missing
  0,0,7,0,0,0,0,0,0,0,7,0,0,
  0,0,0,7,0,0,0,0,0,7,0,0,0,
  0,0,0,0,7,0,0,0,7,0,0,0,0,
  0,0,0,0,0,7,0,7,0,0,0,0,0,
  0,0,0,0,0,7,0,7,0,0,0,0,0,
  0,0,0,0,7,0,0,0,7,0,0,0,0,
  0,0,0,7,0,0,0,0,0,7,0,0,0,
  0,0,7,0,0,0,0,0,0,0,7,0,0
};

// Icon shown when there is no alarm
void showIdle() {
  matrix.draw(thermoOk ? iconHealthy : iconSensorError);
}

// Called by Python via Bridge.notify("set_alert_state", bool).
// Registered with provide_safe, so it runs in loop() context: it only stores
// the request, and loop() applies it.
void set_alert_state(bool state) {
  alertRequested = state;
  lastAlertMsg = millis();
}

void startAlarm() {
  alertActive = true;
  blinkOn = false;
  lastBlinkToggle = 0;                   // flash immediately
  Monitor.println("ALERT: alarm ON");
}

void stopAlarm() {
  alertActive = false;
  if (buzzerOk) buzzer.tone(0, 10);      // silence
  showIdle();
  Monitor.println("ALERT: alarm OFF");
}

void setup() {
  Bridge.begin();
  Monitor.begin();

  matrix.begin();
  matrix.setGrayscaleBits(3);            // brightness values 0-7
  matrix.clear();

  // Modulinos are on the Qwiic connector, which is Wire1 on the UNO Q
  Modulino.begin(Wire1);

  thermoOk = thermo.begin();
  Monitor.println(thermoOk ? "OK: Modulino Thermo ready." : "ERROR: Modulino Thermo not detected!");

  buzzerOk = buzzer.begin();
  Monitor.println(buzzerOk ? "OK: Modulino Buzzer ready." : "ERROR: Modulino Buzzer not detected!");

  Bridge.provide_safe("set_alert_state", set_alert_state);

  showIdle();
  Monitor.println("Artemis MCU node ready.");
}

void loop() {
  unsigned long now = millis();

  // 1. Read the Thermo and push it to Python
  if (now - lastSensorRead >= SENSOR_PERIOD_MS) {
    lastSensorRead = now;
    if (!thermoOk) {
      thermoOk = thermo.begin();         // retry, in case it was plugged in late
      if (thermoOk) { Monitor.println("OK: Modulino Thermo detected."); if (!alertActive) showIdle(); }
    }
    if (thermoOk) {
      float tempC = thermo.getTemperature();
      float humPct = thermo.getHumidity();
      if (!isnan(tempC) && !isnan(humPct)) {
        Bridge.notify("on_thermo_data", tempC, humPct);
      }
    }
  }

  // 2. Apply Python's request; drop the alarm if Python went silent
  bool wanted = alertRequested && (now - lastAlertMsg < ALERT_TIMEOUT_MS);
  if (wanted && !alertActive) startAlarm();
  else if (!wanted && alertActive) stopAlarm();

  // 3. Non-blocking alarm: flash the "!" and beep in sync
  if (alertActive && now - lastBlinkToggle >= BLINK_PERIOD_MS) {
    lastBlinkToggle = now;
    blinkOn = !blinkOn;
    if (blinkOn) {
      matrix.draw(iconAlert);
      if (buzzerOk) buzzer.tone(BEEP_FREQ_HZ, BEEP_LEN_MS);
    } else {
      matrix.clear();
    }
  }
}
