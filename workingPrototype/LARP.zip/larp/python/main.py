# Artemis AI - livestock health monitor (Arduino UNO Q)
#
# MPU side (this file):
#   - receives temperature/humidity from the sketch (Modulino Thermo) over the Bridge
#   - computes the cattle Temperature-Humidity Index (THI)
#   - vision pipeline, same as the training data (crop-and-keypoints-yolox-rtmpose.ipynb):
#       1. YoloX nano (Video Object Detection brick) finds the cow in the camera feed
#       2. the best cow box is cropped to 256x256
#       3. a detected cow starts a 2.5 s recording at 10 fps (25 frames)
#       4. RTMPose-m (AP-10K, 17 keypoints) runs on each frame; the keypoints are turned
#          into the 20 AnimalPose points (missing ones synthesised) in the training CSV format
#       5. the lameness TCN (python/arduino_model.onnx) rates the sequence; if the cow is
#          still there, the dashboard flashes HEALTHY / LAME
#   - fuses THI with the vision AI "sick" probability into one risk score
#   - tells the sketch when to raise / clear the alarm (LED matrix + Modulino Buzzer)
#   - serves the dashboard (assets/index.html) through the WebUI brick on port 7000
#
# MCU side (sketch/sketch.ino): reads the sensor, drives the matrix and the buzzer.

import random
import shutil
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

import cv2
import numpy as np

from arduino.app_bricks.video_objectdetection import VideoObjectDetection
from arduino.app_bricks.web_ui import WebUI
from arduino.app_peripherals.camera import Camera
from arduino.app_utils import App, Bridge

# --- CONFIGURATION ---
# Classifier labels that count as "sick". Match these to the labels of your
# Edge Impulse model once it is trained (comparison is case-insensitive).
SICK_LABELS = {"sick", "diseased", "unhealthy", "lumpy_skin", "mastitis", "lameness"}

DISEASE_CONF_THRESHOLD = 0.65   # Vision confidence that triggers a quarantine alert
SUSPECT_THRESHOLD = 0.35        # Simulated pens: sick probability that marks a pen SUSPECT
THI_WARNING_THRESHOLD = 74.0    # THI >= 74 = "alert" heat stress for cattle
THI_HYSTERESIS = 1.0            # THI must drop this much below the threshold to clear
                                # the alarm, so the buzzer doesn't flap at ~74
SENSOR_TIMEOUT_S = 10.0         # No sensor data for this long -> report sensor offline
MESH_TICK_S = 2.5               # Period of the simulated Zigbee mesh update
MESH_LOG_LINES = 20             # Mesh log lines kept for the dashboard
MESH_PACKET_LOSS = 0.04         # Chance of a simulated lost packet per pen per tick (lively mode)

# Risk score weights (must add up to 1.0)
VISION_WEIGHT = 0.70
THI_WEIGHT = 0.30

# Vision pipeline
COW_LABEL = "cow"               # COCO class name reported by YoloX nano
DETECT_CONFIDENCE = 0.45        # Minimum detector confidence for a cow box
COW_TIMEOUT_S = 3.0             # No cow box for this long -> "0 cows in view"
POSE_MODEL_PATH = Path(__file__).parent / "rtmpose_ap10k.onnx"
# Pretrained RTMPose-m AP-10K, already exported to ONNX by OpenMMLab (downloaded once)
POSE_MODEL_URL = ("https://download.openmmlab.com/mmpose/v1/projects/rtmposev1/onnx_sdk/"
                  "rtmpose-m_simcc-ap10k_pt-aic-coco_210e-256x256-7a041aa1_20230206.zip")
POSE_INPUT = 256                # RTMPose input size (square)
POSE_BBOX_PADDING = 1.25        # Enlarge the cow box so legs/tail stay in the crop
POSE_THREADS = 3                # onnxruntime threads: pose only runs in bursts, after a recording
KEYPOINT_MIN_SCORE = 0.3        # Keypoints below this score count as not visible

# Gait check: when a cow shows up, record GAIT_RECORD_S of it, downsample to GAIT_FPS frames,
# run the pose model on each frame (like preprocessing/crop-and-keypoints.ipynb on a video),
# then pass the keypoint sequence through the lameness TCN (cow_lameness_tcn.ipynb).
GAIT_MODEL_PATH = Path(__file__).parent / "arduino_model.onnx"
GAIT_RECORD_S = 2.5             # Length of one recording: 25 frames = one TCN input, one pass
GAIT_FPS = 10.0                 # Frame rate of the training data (video_to_frames target_fps)
GAIT_MIN_FRAMES = 25            # Camera frames needed out of the 25: all of them
GAIT_NOTE_S = 4.0               # How long the dashboard shows "no result" notes
GAIT_COOLDOWN_S = 5.0           # Pause after a result before the next recording
GAIT_RESULT_S = 8.0             # How long the dashboard flashes the verdict
GAIT_LAME_THRESHOLD = 0.5       # Decision threshold used in training
TEST_STRIDE = 5                 # Window stride of predict_video() in the notebook
TRAIN_CROP_SIZE = 256           # Databuilder width/height: x, y are in this crop's pixels
TRAIN_CROP_PAD = 0.15           # Databuilder pad, per side of the cow box
GAIT_CONF_THR = 0.3             # CONF_THR: keypoints below it are treated as missing
SMOOTH_WIN, SMOOTH_ORDER = 5, 2 # Savitzky-Golay smoothing of the keypoint tracks
TAIL, WITHERS, NOSE = 4, 3, 2   # AP-10K Root_of_tail, Neck, Nose (for a model retrained on AP-10K)

# arduino_model.onnx was trained on the 20 AnimalPose keypoints. They are built from the 17
# AP-10K points: shared points are copied, the missing ones are synthesised as weighted sums
# of nearby AP-10K points ({AP-10K index: weight}). Synthetic points get the lowest score of
# their sources.
ANIMALPOSE_FROM_AP10K = [
    ("L_Eye", {0: 1.0}), ("R_Eye", {1: 1.0}),
    ("L_EarBase", {0: 1.5, 2: -0.5}),             # synthetic: behind the eye, away from the nose
    ("R_EarBase", {1: 1.5, 2: -0.5}),             # synthetic
    ("Nose", {2: 1.0}),
    ("Throat", {2: 0.4, 3: 0.6}),                 # synthetic: between nose and neck
    ("TailBase", {4: 1.0}),
    ("Withers", {3: 1.0}),                        # AP-10K neck sits at the withers
    ("L_F_Elbow", {6: 1.0}), ("R_F_Elbow", {9: 1.0}),
    ("L_B_Elbow", {12: 1.0}), ("R_B_Elbow", {15: 1.0}),
    ("L_F_Knee", {6: 0.5, 7: 0.5}),               # synthetic: between elbow and paw
    ("R_F_Knee", {9: 0.5, 10: 0.5}),              # synthetic
    ("L_B_Knee", {12: 0.5, 13: 0.5}),             # synthetic: between knee and paw
    ("R_B_Knee", {15: 0.5, 16: 0.5}),             # synthetic
    ("L_F_Paw", {7: 1.0}), ("R_F_Paw", {10: 1.0}),
    ("L_B_Paw", {13: 1.0}), ("R_B_Paw", {16: 1.0}),
]
ANIMALPOSE_TAIL_WITHERS_NOSE = (6, 7, 4)

# AP-10K keypoint order returned by the pose model
AP10K_KEYPOINTS = [
    "left_eye", "right_eye", "nose", "neck", "root_of_tail",
    "left_shoulder", "left_elbow", "left_front_paw",
    "right_shoulder", "right_elbow", "right_front_paw",
    "left_hip", "left_knee", "left_back_paw",
    "right_hip", "right_knee", "right_back_paw",
]

# Simulated neighbour pens - placeholder data for the demo, not real devices.
# base_* is the pen's normal climate; in lively mode "event" disturbs it:
#   "heatwave" pushes THI past 74 (HEAT STRESS), "warm_spell" stays below it.
MESH_PENS = [
    {"id": "PEN-02 (Calves)", "hops": 1, "base_rssi": -52, "base_temp": 21.0, "base_hum": 55.0,
     "cows": 12, "event": "warm_spell", "event_temp": 4.0},
    {"id": "PEN-03 (Dairy)", "hops": 2, "base_rssi": -61, "base_temp": 22.5, "base_hum": 60.0,
     "cows": 24, "event": "heatwave", "event_temp": 5.5},
    {"id": "PEN-04 (Isolation)", "hops": 2, "base_rssi": -67, "base_temp": 20.0, "base_hum": 50.0,
     "cows": 0, "event": None, "event_temp": 0.0, "isolation": True},
]
# event: ((min, max) seconds between events, (min, max) seconds an event lasts)
MESH_EVENTS = {
    "heatwave": ((150, 300), (90, 150)),
    "warm_spell": ((120, 240), (45, 75)),
}

# Demo scenarios (Demo controls). Curves are (seconds since start, sick probability)
# points, interpolated - the way a gait model grows more certain while it watches.
DEMO_LIMP_CURVE = [(0, 0.08), (5, 0.18), (10, 0.40), (15, 0.62), (20, 0.78), (25, 0.86)]
# Outbreak only: PEN-03 shares PEN-01's feed and water area and gets infected later
DEMO_PEN03_CURVE = [(45, 0.10), (55, 0.30), (65, 0.48), (78, 0.70), (90, 0.82)]
DEMO_PEN03_SICK_COWS = 2        # Cows PEN-03 sends to isolation once quarantined

# --- SHARED STATE ---
# Written by the Bridge thread, the web API threads and the main loop,
# so every access goes through state_lock.
state = {
    "pen1": {
        "status": "HEALTHY",          # HEALTHY | HEAT STRESS | QUARANTINE ALERT
        "vision_label": "n/a",
        "disease_prob": 0.0,
        "vision_active": False,       # True once a real classifier reports results
        "detector_online": False,     # True once the cow detector reports
        "cows_detected": 0,
        "cow_conf": 0.0,
        "pose_active": False,         # True when the pose model is loaded
        "pose_fps": 0.0,
        "keypoints_visible": 0,       # Keypoints above KEYPOINT_MIN_SCORE in the last pose
        "temp_c": None,
        "humidity": None,
        "thi": None,
        "sensor_online": False,
        "risk_score": 0,
        "alert_active": False,
    },
    # Simulated neighbour pens, built from MESH_PENS (see make_mesh_node)
    "zigbee_mesh": [],
    "zigbee_logs": [],
    "mesh_calm": False,               # True = calm mode: no events, no packet loss
    # Running demo scenario: kind None | "limp" | "outbreak"
    "demo": {"kind": None, "start": 0.0, "pen02_restricted": False},
}
state_lock = threading.RLock()
last_sensor_ts = 0.0
last_cow_ts = 0.0
heat_stress_latched = False     # Hysteresis memory for the THI alarm
mesh_quarantine_prev = False    # PEN-01 quarantine state seen by the last mesh tick


def compute_thi(temp_c: float, humidity_pct: float) -> float:
    """Livestock Temperature-Humidity Index (Thom / NRC formula, °C input).

    Cattle guide values: < 68 comfort, 68-72 mild stress, 72-79 moderate, >= 80 severe.
    """
    rh = humidity_pct / 100.0
    return round(0.8 * temp_c + rh * (temp_c - 14.4) + 46.4, 1)


def send_alert_state(active: bool):
    """Tell the sketch whether the alarm should be on. Fire-and-forget."""
    try:
        Bridge.notify("set_alert_state", active)
    except Exception as e:
        print(f"[BRIDGE ERROR] set_alert_state: {e}", flush=True)


def evaluate_health_state():
    """Fuse vision + THI into a risk score and status, and update the alarm."""
    global heat_stress_latched

    with state_lock:
        p1 = state["pen1"]
        was_active = p1["alert_active"]
        disease_prob = p1["disease_prob"]
        thi = p1["thi"]

        # Heat stress with hysteresis: switch on at the threshold,
        # switch off only once THI is clearly below it again.
        if thi is not None:
            if thi >= THI_WARNING_THRESHOLD:
                heat_stress_latched = True
            elif thi < THI_WARNING_THRESHOLD - THI_HYSTERESIS:
                heat_stress_latched = False

        # Weighted risk score 0-100: THI contributes 0 at 68 and saturates at 78
        thi_factor = 0.0 if thi is None else max(0.0, min(1.0, (thi - 68.0) / 10.0))
        risk = round((VISION_WEIGHT * disease_prob + THI_WEIGHT * thi_factor) * 100)
        p1["risk_score"] = min(100, int(risk))

        if disease_prob >= DISEASE_CONF_THRESHOLD:
            p1["status"] = "QUARANTINE ALERT"
        elif heat_stress_latched:
            p1["status"] = "HEAT STRESS"
        else:
            p1["status"] = "HEALTHY"

        p1["alert_active"] = p1["status"] != "HEALTHY"
        now_active = p1["alert_active"]

    if now_active != was_active:
        print(f"[ALERT] {'RAISED' if now_active else 'CLEARED'} - status={p1['status']}", flush=True)
        send_alert_state(now_active)


# --- BRIDGE: sensor data from the sketch (Modulino Thermo, every 2 s) ---
def on_thermo_data(temp_c: float, humidity_pct: float):
    global last_sensor_ts
    if temp_c is None or humidity_pct is None:
        return
    temp_c, humidity_pct = float(temp_c), float(humidity_pct)
    if temp_c != temp_c or humidity_pct != humidity_pct:   # NaN check
        return

    with state_lock:
        p1 = state["pen1"]
        p1["temp_c"] = round(temp_c, 1)
        p1["humidity"] = round(humidity_pct, 1)
        p1["thi"] = compute_thi(temp_c, humidity_pct)
        p1["sensor_online"] = True
        alert = p1["alert_active"]
        last_sensor_ts = time.time()

    evaluate_health_state()
    # Re-send the current alarm state with every sample as a heartbeat, so the
    # sketch resyncs if a notify was lost or the MCU was reset.
    send_alert_state(alert)


Bridge.provide("on_thermo_data", on_thermo_data)


# --- VISION AI HOOK ---
def on_vision_results(scores: dict):
    """Feed classifier output here: {label: confidence, ...}.

    Called by the gait worker with the result of each gait check; labels in
    SICK_LABELS count towards the sick probability.
    """
    if not scores:
        return
    sick_score = max((float(v) for k, v in scores.items() if k.lower() in SICK_LABELS), default=0.0)
    top_label = max(scores, key=scores.get)
    with state_lock:
        p1 = state["pen1"]
        p1["vision_active"] = True
        if state["demo"]["kind"]:
            return   # a running demo scenario drives the sick probability
        p1["disease_prob"] = round(sick_score, 3)
        p1["vision_label"] = top_label
    evaluate_health_state()


# --- YOUR MODEL: gait / lameness TCN on keypoints ---
class GaitModel:
    """Lameness TCN (ONNX): features [1, channels, frames] -> one logit (lame = positive)."""

    def __init__(self, model_path: Path):
        import onnxruntime as ort

        opts = ort.SessionOptions()
        opts.intra_op_num_threads = 1
        self.session = ort.InferenceSession(str(model_path), opts, providers=["CPUExecutionProvider"])
        inp = self.session.get_inputs()[0]
        self.input_name = inp.name
        channels, self.frames = int(inp.shape[1]), int(inp.shape[2])
        self.keypoints = (channels - 2) // 5
        if channels == 5 * len(AP10K_KEYPOINTS) + 2:
            self.layout = (TAIL, WITHERS, NOSE)
        elif channels == 5 * len(ANIMALPOSE_FROM_AP10K) + 2:
            self.layout = ANIMALPOSE_TAIL_WITHERS_NOSE
        else:
            raise ValueError(f"model expects {channels} channels: neither 17 (AP-10K) "
                             f"nor 20 (AnimalPose) keypoints per frame")

    def __call__(self, feats: np.ndarray) -> float:
        logit = self.session.run(None, {self.input_name: np.ascontiguousarray(feats.T[None])})[0]
        return float(1.0 / (1.0 + np.exp(-float(np.ravel(logit)[0]))))


def savgol(x: np.ndarray) -> np.ndarray:
    """scipy.signal.savgol_filter(x, SMOOTH_WIN, SMOOTH_ORDER, axis=0), mode 'interp', in numpy."""
    n, h = len(x), SMOOTH_WIN // 2
    v = np.vander(np.arange(SMOOTH_WIN, dtype=np.float64), SMOOTH_ORDER + 1)
    fit = v @ np.linalg.pinv(v)   # least-squares polynomial fit over one window
    out = np.empty_like(x)
    out[h:n - h] = sum(fit[h, j] * x[j:n - SMOOTH_WIN + 1 + j] for j in range(SMOOTH_WIN))
    out[:h] = np.tensordot(fit[:h], x[:SMOOTH_WIN], axes=1)
    out[n - h:] = np.tensordot(fit[h + 1:], x[n - SMOOTH_WIN:], axes=1)
    return out


def preprocess(xy: np.ndarray, score: np.ndarray, tail: int, withers: int, nose: int) -> np.ndarray:
    """Port of preprocess() in cow_lameness_tcn.ipynb: xy [T, K, 2] crop pixels,
    score [T, K] -> features [T, 5*K+2]. Keep the two in sync."""
    xy = xy.astype(np.float64)
    xy[score < GAIT_CONF_THR] = np.nan
    idx = np.arange(len(xy))
    for k in range(xy.shape[1]):
        for c in range(2):
            ok = ~np.isnan(xy[:, k, c])
            if ok.any():   # same as pandas interpolate(limit_direction="both")
                xy[:, k, c] = np.interp(idx, idx[ok], xy[ok, k, c])
    xy = np.nan_to_num(xy)

    if len(xy) >= SMOOTH_WIN:
        xy = savgol(xy)

    if np.mean(xy[:, nose, 0] - xy[:, tail, 0]) < 0:   # make every cow face right
        xy[..., 0] *= -1

    root = (xy[:, tail] + xy[:, withers]) / 2
    body_len = np.linalg.norm(xy[:, withers] - xy[:, tail], axis=-1).mean() + 1e-6
    xy = (xy - root[:, None]) / body_len

    vel = np.diff(xy, axis=0, prepend=xy[:1])
    root_vel = np.diff(root / body_len, axis=0, prepend=root[:1] / body_len)
    feats = np.concatenate([xy.reshape(len(xy), -1), vel.reshape(len(xy), -1), score, root_vel], axis=1)
    return feats.astype(np.float32)


def to_animalpose(xy: np.ndarray, score: np.ndarray):
    """AP-10K keypoints [17, 2] + scores [17] -> AnimalPose [20, 2] + [20], with synthetic points."""
    xy20 = np.stack([sum(w * xy[i] for i, w in src.items()) for _, src in ANIMALPOSE_FROM_AP10K])
    score20 = np.array([min(score[i] for i in src) for _, src in ANIMALPOSE_FROM_AP10K])
    return xy20, score20


def keypoint_sequence(poses: dict) -> list:
    """Poses of one recording -> rows in the preprocessing/ CSV format
    (image, keypoint, x, y, score, x_full, y_full).

    poses: {frame index: (keypoints [K, 2] camera px, scores [K], bbox_xyxy, (frame_w, frame_h))}
    x, y are in the 256x256 crop of Databuilder(size_mode="video"): one square crop size for
    the whole recording, positioned on the cow and kept inside the frame.
    """
    boxes = np.array([p[2] for p in poses.values()], dtype=np.float64)
    side = int(round((np.maximum(boxes[:, 2] - boxes[:, 0], boxes[:, 3] - boxes[:, 1])
                      * (1 + 2 * TRAIN_CROP_PAD)).max()))
    rows = []
    for i, (keypoints, scores, box, (frame_w, frame_h)) in sorted(poses.items()):
        origin = []
        for center, limit in (((box[0] + box[2]) / 2, frame_w), ((box[1] + box[3]) / 2, frame_h)):
            start = center - side / 2   # Databuilder._place
            if side <= limit:
                start = min(max(start, 0), limit - side)
            origin.append(int(round(start)))
        for k, ((x_full, y_full), score) in enumerate(zip(keypoints, scores)):
            rows.append({
                "image": f"{i:06d}.jpg", "keypoint": k,
                "x": round((float(x_full) - origin[0]) * TRAIN_CROP_SIZE / side, 2),
                "y": round((float(y_full) - origin[1]) * TRAIN_CROP_SIZE / side, 2),
                "score": round(float(score), 4),
                "x_full": round(float(x_full), 2), "y_full": round(float(y_full), 2),
            })
    return rows


def predict_sequence(rows: list) -> float | None:
    """load_video() + preprocess() + predict_video() of the notebook on one recording.
    Returns the lameness probability, or None if the sequence is shorter than one window."""
    frames = np.array([int(r["image"][:6]) for r in rows])
    frames -= frames.min()
    arr = np.full((frames.max() + 1, gait_model.keypoints, 3), np.nan)
    arr[frames, [r["keypoint"] for r in rows]] = [(r["x"], r["y"], r["score"]) for r in rows]
    if len(arr) < gait_model.frames:
        return None

    feats = preprocess(arr[..., :2], np.nan_to_num(arr[..., 2]), *gait_model.layout)
    starts = list(range(0, len(feats) - gait_model.frames + 1, TEST_STRIDE))
    if starts[-1] != len(feats) - gait_model.frames:
        starts.append(len(feats) - gait_model.frames)
    return float(np.mean([gait_model(feats[s:s + gait_model.frames]) for s in starts]))


gait_model = None


# --- POSE ESTIMATION: RTMPose (AP-10K) on onnxruntime ---
# Keep in sync with training/cattle_keypoints_ap10k.ipynb, which builds the training data.
class PoseEstimator:
    """Top-down animal pose: crops the cow box to 256x256 and runs RTMPose."""

    MEAN = np.array([123.675, 116.28, 103.53], dtype=np.float32)
    STD = np.array([58.395, 57.12, 57.375], dtype=np.float32)

    def __init__(self, model_path: Path):
        import onnxruntime as ort

        opts = ort.SessionOptions()
        opts.intra_op_num_threads = POSE_THREADS
        self.session = ort.InferenceSession(str(model_path), opts, providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name

    def __call__(self, image_bgr: np.ndarray, bbox_xyxy):
        x1, y1, x2, y2 = (float(v) for v in bbox_xyxy)
        cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
        side = max(x2 - x1, y2 - y1, 1.0) * POSE_BBOX_PADDING
        scale = POSE_INPUT / side

        # Square crop centred on the cow; parts outside the frame are filled black
        m = np.array([[scale, 0, POSE_INPUT / 2 - scale * cx],
                      [0, scale, POSE_INPUT / 2 - scale * cy]], dtype=np.float32)
        crop = cv2.warpAffine(image_bgr, m, (POSE_INPUT, POSE_INPUT), flags=cv2.INTER_LINEAR)
        rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB).astype(np.float32)
        blob = ((rgb - self.MEAN) / self.STD).transpose(2, 0, 1)[None]

        # SimCC heads: one 1-D distribution per axis per keypoint
        simcc_x, simcc_y = self.session.run(None, {self.input_name: blob})[:2]
        split_x = simcc_x.shape[-1] / POSE_INPUT
        split_y = simcc_y.shape[-1] / POSE_INPUT
        kx = simcc_x[0].argmax(-1) / split_x
        ky = simcc_y[0].argmax(-1) / split_y
        scores = np.minimum(simcc_x[0].max(-1), simcc_y[0].max(-1)).astype(np.float32)

        # Crop coordinates -> camera pixels
        keypoints = np.stack([(kx - POSE_INPUT / 2) / scale + cx,
                              (ky - POSE_INPUT / 2) / scale + cy], axis=-1).astype(np.float32)
        return keypoints, scores


def download_pose_model():
    """One-time download of the pretrained ONNX model (OpenMMLab zip) next to main.py."""
    zip_part = POSE_MODEL_PATH.with_name(POSE_MODEL_PATH.name + ".zip.part")
    onnx_part = POSE_MODEL_PATH.with_name(POSE_MODEL_PATH.name + ".part")
    print("[POSE] Downloading pretrained RTMPose-m (AP-10K), one time only...", flush=True)
    urllib.request.urlretrieve(POSE_MODEL_URL, zip_part)
    with zipfile.ZipFile(zip_part) as z:
        name = next(n for n in z.namelist() if n.endswith(".onnx"))
        with z.open(name) as src, open(onnx_part, "wb") as dst:
            shutil.copyfileobj(src, dst)
    onnx_part.replace(POSE_MODEL_PATH)   # only a complete file gets the final name
    zip_part.unlink(missing_ok=True)
    print(f"[POSE] Saved python/{POSE_MODEL_PATH.name}", flush=True)


pose_estimator = None

# Gait check state (under state_lock). phase: idle -> recording -> analysing -> idle.
# recording = {frame index: (timestamp, BGR frame)}: the first camera frame of every
# 1/GAIT_FPS slot, like video_to_frames(target_fps=10). The camera runs at 10 fps, so a
# 2.5 s recording holds all 25 frames. The detector only rates ~1-2 frames/s, so the cow box
# of each frame is interpolated in time between the detections (recording_boxes).
gait = {"phase": "idle", "start": 0.0, "done": 0, "total": 0, "next": 0.0, "result": None, "note": None,
        "rows": []}
GAIT_SLOTS = round(GAIT_RECORD_S * GAIT_FPS)
recording = {}
recording_boxes = []   # (timestamp, bbox_xyxy) of the best cow box of each detection
recording_started = threading.Event()


def on_camera_frame(frame: np.ndarray):
    """Every camera frame passes here on its way to the detector (10 fps, BGR)."""
    now = time.time()
    with state_lock:
        if gait["phase"] != "recording":
            return
        slot = int((now - gait["start"]) * GAIT_FPS)
        if slot < GAIT_SLOTS and slot not in recording:
            recording[slot] = (now, frame)


def box_at(boxes: list, t: float) -> list:
    """Cow box at time t, linearly interpolated between detections (clamped at the ends)."""
    times = [b[0] for b in boxes]
    return [float(np.interp(t, times, [float(b[1][c]) for b in boxes])) for c in range(4)]


def gait_info():
    """Gait check for the dashboard. Call with state_lock held."""
    now = time.time()
    result = gait["result"]
    return {
        "phase": gait["phase"],
        "elapsed": round(min(now - gait["start"], GAIT_RECORD_S), 1) if gait["phase"] == "recording" else 0,
        "record_s": GAIT_RECORD_S, "done": gait["done"], "total": gait["total"],
        "result": result if result and now - result["time"] < GAIT_RESULT_S else None,
        "note": gait["note"]["text"] if gait["note"] and now - gait["note"]["time"] < GAIT_NOTE_S else None,
    }


def gait_note(text: str):
    """Log a gait check that gave no verdict and show it briefly on the dashboard."""
    print(f"[GAIT] {text}", flush=True)
    with state_lock:
        gait["note"] = {"text": text, "time": time.time()}


def analyse_recording(frames: dict, boxes: list):
    """Pose on every recorded frame -> keypoint sequence -> lameness TCN."""
    t0 = time.time()
    poses = {}
    for n, (i, (t, image)) in enumerate(sorted(frames.items()), 1):
        bbox = box_at(boxes, t)
        keypoints, scores = pose_estimator(image, bbox)
        visible = int((scores >= KEYPOINT_MIN_SCORE).sum())
        if gait_model.keypoints != len(AP10K_KEYPOINTS):
            keypoints, scores = to_animalpose(keypoints, scores)
        poses[i] = (keypoints, scores, bbox, image.shape[1::-1])
        with state_lock:
            gait["done"] = n
            state["pen1"]["pose_fps"] = round(n / (time.time() - t0), 1)
            state["pen1"]["keypoints_visible"] = visible
    if not poses:
        return None, []
    rows = keypoint_sequence(poses)
    return predict_sequence(rows), rows


def gait_worker():
    """Loads the models, then runs one gait check per recording."""
    global pose_estimator, gait_model
    try:
        if not POSE_MODEL_PATH.is_file():
            download_pose_model()
        estimator = PoseEstimator(POSE_MODEL_PATH)
    except Exception as e:
        print(f"[POSE] Pose disabled, detection only - could not get the model: {e}", flush=True)
        return
    pose_estimator = estimator
    with state_lock:
        state["pen1"]["pose_active"] = True
    print(f"[POSE] Loaded {POSE_MODEL_PATH.name} - keypoints enabled", flush=True)

    try:
        gait_model = GaitModel(GAIT_MODEL_PATH)
        print(f"[GAIT] Loaded {GAIT_MODEL_PATH.name} - {gait_model.frames} frames at {GAIT_FPS:g} fps, "
              f"{gait_model.keypoints} keypoints", flush=True)
        if gait_model.keypoints != len(AP10K_KEYPOINTS):
            print("[GAIT] Model trained on AnimalPose keypoints: AP-10K mapped to AnimalPose, "
                  "results are approximate until it is retrained on AP-10K", flush=True)
    except Exception as e:
        print(f"[GAIT] Gait model disabled ({GAIT_MODEL_PATH.name}): {e}", flush=True)
        return

    while True:
        recording_started.wait()
        recording_started.clear()
        with state_lock:
            wait_s = gait["start"] + GAIT_RECORD_S - time.time()
        time.sleep(max(0.0, wait_s))

        with state_lock:
            frames = dict(recording)
            boxes = list(recording_boxes)
            recording.clear()
            recording_boxes.clear()
            gait.update(phase="analysing", done=0, total=len(frames))
        print(f"[GAIT] Recorded {GAIT_RECORD_S:g} s: {len(frames)}/{GAIT_SLOTS} frames at {GAIT_FPS:g} fps, "
              f"{len(boxes)} cow detections", flush=True)

        prob, rows = None, []
        if len(frames) >= GAIT_MIN_FRAMES:
            try:
                prob, rows = analyse_recording(frames, boxes)
            except Exception as e:
                print(f"[GAIT ERROR] {e}", flush=True)
            if prob is None and rows:
                gait_note(f"No result: the recording covers less than "
                          f"{gait_model.frames / GAIT_FPS:g} s, retrying")
        else:
            gait_note(f"No result: the camera gave only {len(frames)}/{GAIT_SLOTS} frames "
                      f"(need {GAIT_MIN_FRAMES}), retrying")

        with state_lock:
            still_there = time.time() - last_cow_ts < COW_TIMEOUT_S
            gait["rows"] = rows
            if prob is not None and still_there:
                label = "LAME" if prob >= GAIT_LAME_THRESHOLD else "HEALTHY"
                gait["result"] = {"label": label, "prob": round(prob, 3), "frames": len(frames),
                                  "time": time.time()}
            gait.update(phase="idle", next=time.time() + GAIT_COOLDOWN_S)

        if prob is None:
            continue
        if still_there:
            print(f"[GAIT] Result: {label} (lameness {prob:.0%}, {len(frames)} frames)", flush=True)
            on_vision_results({"lameness": prob, "healthy": 1.0 - prob})
        else:
            gait_note(f"No result shown: the cow left before the analysis finished (lameness {prob:.0%})")


# --- COW DETECTION: YoloX nano via the Video Object Detection brick ---
def on_detections(detections: dict):
    global last_cow_ts
    cows = [d for label, items in detections.items() if label.lower() == COW_LABEL for d in items]
    now = time.time()
    with state_lock:
        p1 = state["pen1"]
        p1["detector_online"] = True
        if cows:
            last_cow_ts = now
            p1["cows_detected"] = len(cows)
            p1["cow_conf"] = round(max(float(c["confidence"]) for c in cows), 2)

        if not cows or gait_model is None:
            return
        # A cow starts a recording (frames come from on_camera_frame); its boxes locate the cow
        best = max(cows, key=lambda c: float(c["confidence"]))
        if gait["phase"] == "idle" and now >= gait["next"]:
            gait.update(phase="recording", start=now, done=0, total=0)
            recording.clear()
            recording_boxes.clear()
            recording_started.set()
            print("[GAIT] Cow detected - recording", flush=True)
        if gait["phase"] == "recording":
            recording_boxes.append((now, best["bounding_box_xyxy"]))


# --- WEB API (used by assets/app.js) ---
def api_status():
    now = time.time()
    with state_lock:
        # Copy so the response isn't serialised while another thread mutates it;
        # "_" fields are simulation internals.
        mesh = []
        for n in state["zigbee_mesh"]:
            node = {k: v for k, v in n.items() if not k.startswith("_")}
            node["last_rx_s"] = int(now - n["last_rx"])
            mesh.append(node)
        return {
            "pen1": dict(state["pen1"]),
            "zigbee_mesh": mesh,
            "zigbee_logs": list(state["zigbee_logs"]),
            "mesh_calm": state["mesh_calm"],
            "demo": demo_info(),
            "gait": gait_info(),
        }


def api_gait_sequence():
    """Keypoint sequence of the last gait check, in the preprocessing/ CSV format."""
    with state_lock:
        return {"columns": ["image", "keypoint", "x", "y", "score", "x_full", "y_full"],
                "rows": list(gait["rows"])}


def api_demo(action: str):
    """Demo buttons: 'limp' (limping cow in PEN-01), 'outbreak' (spreads to PEN-03),
    'reset', 'calm' / 'lively' (simulated neighbour pens)."""
    stamp = time.strftime("%H:%M:%S")
    if action in ("calm", "lively"):
        with state_lock:
            state["mesh_calm"] = action == "calm"
            mesh_log(stamp, "ZIGBEE_EVT mesh calm mode ON - no events, no packet loss" if state["mesh_calm"]
                            else "ZIGBEE_EVT mesh lively mode ON")
        return {"ok": True}

    with state_lock:
        if action in ("limp", "outbreak"):
            state["demo"] = {"kind": action, "start": time.time(), "pen02_restricted": False}
            mesh_node("PEN-03")["_sick"] = None
            print(f"[DEMO] {action} scenario started", flush=True)
        elif action == "reset":
            state["demo"] = {"kind": None, "start": 0.0, "pen02_restricted": False}
            mesh_node("PEN-03")["_sick"] = None
            state["pen1"]["disease_prob"], state["pen1"]["vision_label"] = 0.0, "healthy"
            print("[DEMO] reset", flush=True)
        else:
            return {"ok": False, "error": f"unknown action '{action}'"}
    demo_tick()
    evaluate_health_state()
    return {"ok": True}


ui = WebUI()
ui.expose_api("GET", "/api/status", api_status)
ui.expose_api("GET", "/api/gait/sequence", api_gait_sequence)
ui.expose_api("POST", "/api/demo/{action}", api_demo)

# --- USB CAMERA + COW DETECTOR ---
# The brick streams frames + boxes on port 4912 (socket.io), drawn by the dashboard.
# We hand it the camera (USB webcam, 640x480 at GAIT_FPS) and tap its capture() so
# every frame also reaches on_camera_frame() for the gait recordings. If it fails,
# the rest of the app keeps running.
try:
    camera = Camera(fps=int(GAIT_FPS))
    _capture = camera.capture

    def capture_and_record():
        frame = _capture()
        if frame is not None:
            on_camera_frame(frame)
        return frame

    camera.capture = capture_and_record
    detector = VideoObjectDetection(camera=camera, confidence=DETECT_CONFIDENCE, camera_preview=True)
    detector.on_detect_all(on_detections)
    threading.Thread(target=gait_worker, name="gait", daemon=True).start()
    print("[VISION] YoloX nano cow detector started", flush=True)
except Exception as e:
    print(f"[VISION] Could not start the cow detector: {e}", flush=True)


# --- SIMULATED ZIGBEE MESH (neighbour pens, placeholder until real nodes exist) ---
def make_mesh_node(pen: dict) -> dict:
    now = time.time()
    return {
        "id": pen["id"], "hops": pen["hops"], "rssi": pen["base_rssi"],
        "temp_c": pen["base_temp"], "humidity": pen["base_hum"],
        "thi": compute_thi(pen["base_temp"], pen["base_hum"]),
        "cows": pen["cows"], "cows_in_view": pen["cows"], "sick_prob": 0.02,
        "status": "HEALTHY" if pen["cows"] else "STANDBY",
        "last_rx": now,
        # Simulation internals (not sent to the dashboard)
        "_pen": pen, "_offset": 0.0, "_noise": 0.0, "_heat": False,
        "_event_end": 0.0, "_next_event": now + random.uniform(30, 90),
        "_sick": None,   # demo sick probability (outbreak), None = healthy herd
    }


def mesh_node(name: str) -> dict:
    return next(n for n in state["zigbee_mesh"] if n["id"].startswith(name))


def mesh_log(stamp: str, line: str):
    state["zigbee_logs"].insert(0, f"[{stamp}] {line}")
    del state["zigbee_logs"][MESH_LOG_LINES:]


def update_mesh_node(node: dict, now: float, stamp: str, calm: bool, isolating: dict):
    """One tick of a simulated pen. isolating = {pen name: (cows, sick prob)} for
    the pens in QUARANTINE ALERT, whose sick cows go to the isolation pen.
    Call with state_lock held."""
    pen = node["_pen"]
    name = pen["id"].split()[0]

    # Disturbances: only in lively mode; calm mode cancels the running one
    target = 0.0
    if pen["event"]:
        gap, length = MESH_EVENTS[pen["event"]]
        if calm:
            node["_event_end"] = 0.0
            node["_next_event"] = now + random.uniform(30, 90)
        elif now >= node["_next_event"]:
            node["_event_end"] = now + random.uniform(*length)
            node["_next_event"] = node["_event_end"] + random.uniform(*gap)
            if pen["event"] == "warm_spell":
                mesh_log(stamp, f"ZIGBEE_EVT src={name} warm spell, THI rising")
        if now < node["_event_end"]:
            target = pen["event_temp"]

    # Climate drifts smoothly towards the target; calm mode settles in a few ticks
    node["_offset"] += (target - node["_offset"]) * (0.35 if calm else 0.08)
    jitter = 0.05 if calm else 0.2
    node["_noise"] = 0.9 * node["_noise"] + random.uniform(-jitter, jitter)
    temp = pen["base_temp"] + node["_offset"] + node["_noise"]
    hum = max(20.0, min(95.0, pen["base_hum"] - 1.5 * node["_offset"] + 4 * node["_noise"]))

    if not calm and random.random() < MESH_PACKET_LOSS:
        mesh_log(stamp, f"ZIGBEE_WARN src={name} packet lost, retry 1")
        return   # the dashboard keeps the previous values this tick

    node["temp_c"], node["humidity"] = round(temp, 1), round(hum, 1)
    node["thi"] = thi = compute_thi(temp, hum)
    spread = 1 if calm else 3
    node["rssi"] = pen["base_rssi"] + random.randint(-spread, spread)

    sick = node["_sick"]
    quarantined = sick is not None and sick >= DISEASE_CONF_THRESHOLD
    if pen.get("isolation"):
        isolated_cows = sum(cows for cows, _ in isolating.values())
        herd = pen["cows"] + isolated_cows
        sick_prob = max((p for _, p in isolating.values()), default=round(random.uniform(0.01, 0.05), 2))
    else:
        herd = pen["cows"] - (DEMO_PEN03_SICK_COWS if quarantined else 0)
        sick_prob = sick if sick is not None else round(random.uniform(0.01, 0.05), 2)
    low = herd if herd <= 1 else herd * 2 // 3
    node["cows"] = herd
    node["cows_in_view"] = max(low, min(herd, node["cows_in_view"] + random.choice((-1, 0, 0, 1))))
    node["sick_prob"] = sick_prob

    # Same heat-stress rule and hysteresis as PEN-01
    if thi >= THI_WARNING_THRESHOLD:
        node["_heat"] = True
    elif thi < THI_WARNING_THRESHOLD - THI_HYSTERESIS:
        node["_heat"] = False

    if pen.get("isolation") and isolating:
        status = f"GATE LOCKED (ISOLATING {', '.join(isolating)})"
    elif quarantined:
        status = "QUARANTINE ALERT"
    elif sick is not None and sick >= SUSPECT_THRESHOLD:
        status = "SUSPECT"
    elif node["_heat"]:
        status = "HEAT STRESS"
    else:
        status = "HEALTHY" if herd else "STANDBY"

    old = node["status"]
    if status != old:
        if status.startswith("GATE"):
            verb = "now isolating" if old.startswith("GATE") else "gate LOCKED, isolating"
            msg = f"{verb} {', '.join(isolating)}: {isolated_cows} cow{'s' if isolated_cows > 1 else ''}"
        elif old.startswith("GATE"):
            msg = f"gate RELEASED, now {status}"
        elif status == "SUSPECT":
            msg = f"SUSPECT: {DEMO_PEN03_SICK_COWS} cows lame, sick {round(sick * 100)}%"
        elif status == "QUARANTINE ALERT":
            msg = (f"QUARANTINE ALERT sick {round(sick * 100)}%, "
                   f"{DEMO_PEN03_SICK_COWS} cows sent to isolation")
        elif status == "HEAT STRESS":
            msg = f"HEAT STRESS thi={thi}, fans ON"
        elif old == "HEAT STRESS":
            msg = f"back to {status} thi={thi}, fans OFF"
        else:
            msg = f"back to {status}"
        mesh_log(stamp, f"ZIGBEE_EVT src={name} {msg}")
        node["status"] = status

    node["last_rx"] = now
    mesh_log(stamp, f"ZIGBEE_RX src={name} hops={node['hops']} rssi={node['rssi']}dBm "
                    f"thi={thi} status={status}")


state["zigbee_mesh"] = [make_mesh_node(p) for p in MESH_PENS]


# --- DEMO SCENARIOS: limping cow / outbreak, played step by step ---
def demo_curve(points: list, t: float) -> float:
    return float(np.interp(t, [p[0] for p in points], [p[1] for p in points]))


def demo_tick() -> bool:
    """Advance the running demo. Returns True if one is running."""
    with state_lock:
        demo = state["demo"]
        if not demo["kind"]:
            return False
        t = time.time() - demo["start"]
        p1 = state["pen1"]
        p1["disease_prob"] = round(demo_curve(DEMO_LIMP_CURVE, t), 2)
        p1["vision_label"] = "lameness (demo)"
        if demo["kind"] == "outbreak" and t >= DEMO_PEN03_CURVE[0][0]:
            mesh_node("PEN-03")["_sick"] = round(demo_curve(DEMO_PEN03_CURVE, t), 2)
    return True


def demo_info():
    """Current demo step for the dashboard banner, or None. Call with state_lock held."""
    demo = state["demo"]
    if not demo["kind"]:
        return None
    p1_prob = state["pen1"]["disease_prob"]
    if demo["kind"] == "limp":
        steps = 3
        if p1_prob < SUSPECT_THRESHOLD:
            step, text = 1, "cow walking in PEN-01, tracking its gait"
        elif p1_prob < DISEASE_CONF_THRESHOLD:
            step, text = 2, "uneven gait detected, lameness rising"
        else:
            step, text = 3, "lameness confirmed, cow moved to isolation PEN-04"
    else:
        steps = 4
        pen03 = mesh_node("PEN-03")["_sick"]
        if p1_prob < DISEASE_CONF_THRESHOLD:
            step, text = 1, "cow limping in PEN-01, lameness rising"
        elif pen03 is None or pen03 < SUSPECT_THRESHOLD:
            step, text = 2, "PEN-01 quarantined, cow moved to isolation PEN-04"
        elif pen03 < DISEASE_CONF_THRESHOLD:
            step, text = 3, "PEN-03 suspected (shares PEN-01's feed and water area)"
        else:
            step, text = 4, "PEN-01 and PEN-03 quarantined, PEN-02 protected"
    return {"kind": demo["kind"], "step": step, "steps": steps, "text": text}


# --- MAIN LOOP: sensor watchdog + simulated Zigbee mesh ---
def main_loop():
    global mesh_quarantine_prev
    if demo_tick():
        evaluate_health_state()

    with state_lock:
        # Sensor watchdog: flag the sensor as offline if the sketch stops sending
        if state["pen1"]["sensor_online"] and time.time() - last_sensor_ts > SENSOR_TIMEOUT_S:
            state["pen1"]["sensor_online"] = False
            print("[SENSOR] No Modulino Thermo data - sensor offline?", flush=True)

        # Cow left the view (the detector only reports frames with detections)
        if state["pen1"]["cows_detected"] and time.time() - last_cow_ts > COW_TIMEOUT_S:
            state["pen1"]["cows_detected"] = 0
            state["pen1"]["cow_conf"] = 0.0
            state["pen1"]["keypoints_visible"] = 0

        # Simulated neighbour pens
        now = time.time()
        stamp = time.strftime("%H:%M:%S")
        p1 = state["pen1"]
        quarantine = p1["status"] == "QUARANTINE ALERT"
        if quarantine != mesh_quarantine_prev:
            mesh_quarantine_prev = quarantine
            mesh_log(stamp, "ZIGBEE_TX src=PEN-01 broadcast "
                            + ("QUARANTINE ALERT" if quarantine else "ALL CLEAR"))
            if quarantine:
                for node in state["zigbee_mesh"]:
                    if not node["_pen"].get("isolation"):
                        mesh_log(stamp, f"ZIGBEE_RX src={node['id'].split()[0]} ACK quarantine PEN-01")
        # Pens in quarantine send their sick cows to the isolation pen
        isolating = {}
        if quarantine:
            isolating["PEN-01"] = (1, p1["disease_prob"])
        pen03 = mesh_node("PEN-03")
        if pen03["status"] == "QUARANTINE ALERT":
            isolating["PEN-03"] = (DEMO_PEN03_SICK_COWS, pen03["sick_prob"])
            if state["demo"]["kind"] == "outbreak" and not state["demo"]["pen02_restricted"]:
                state["demo"]["pen02_restricted"] = True
                mesh_log(stamp, "ZIGBEE_EVT src=PEN-02 access restricted, gates to PEN-01/PEN-03 closed")

        for node in state["zigbee_mesh"]:
            update_mesh_node(node, now, stamp, state["mesh_calm"], isolating)

    time.sleep(MESH_TICK_S)


print("[SYSTEM] Artemis AI starting - dashboard on port 7000", flush=True)
App.run(user_loop=main_loop)
